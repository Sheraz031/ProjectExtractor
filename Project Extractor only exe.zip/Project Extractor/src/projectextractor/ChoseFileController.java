package projectextractor;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.*;
import java.util.zip.*;
import javafx.application.Platform;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.*;
import javafx.stage.FileChooser.*;

public class ChoseFileController implements Initializable {

    private FileChooser fChooser;
    int jClasses = 0, csharpClasses = 0, pythonClasses = 0;
    private Button zipChose, fileChose, folderChose;
    ArrayList<String> patharry = new ArrayList<String>();
    @FXML
    private Pane PaneView;
    @FXML
    private TreeTableView<TableData> TreeTableHome;
    @FXML
    private TreeTableColumn<TableData, String> NameColumn;
    private ListView listvew;
    TreeItem<TableData> parent = new TreeItem<>(new TableData("Class Names"));
    int jintf = 0;
    int caIntf = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        PieChart(0, 0, 0);
    }

    @FXML
    public void ChoseReset(ActionEvent event) {
        try {
            //Load second scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ChoseFile.fxml"));
            Parent root = loader.load();
            Stage stage1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage1.hide();
            stage1.setScene(new Scene(root));
            stage1.show();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    @FXML
    public void DetailFile(ActionEvent event) throws IOException {
        if (patharry.size() > 0) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("DetailFile.fxml"));
                Parent root = loader.load();
                DetailFileController detailfileController = loader.getController();
                detailfileController.setPaths(patharry);
                detailfileController.Do();
                Stage stage1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage1.hide();
                stage1.setScene(new Scene(root));
                stage1.show();
            } catch (IOException ex) {
                System.err.println(ex);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Chose File");
            alert.setHeaderText(null);
            alert.setContentText("Please Chose Atleast 1 File\n          Thanks!");
            alert.showAndWait();
        }
    }

    @FXML
    public void Exit(ActionEvent event) {
        Platform.exit();
        System.exit(0);
    }

    public void showWindow(Parent homepage, ActionEvent event) {
        Scene scene = new Scene(homepage);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.hide();
        stage.setScene(scene);
        stage.show();
    }

    public void InsertDataIntoTable(String nm, String typ, String pth) {
        TreeItem<TableData> p1 = new TreeItem<>(new TableData(nm));
        TreeItem<TableData> p2 = new TreeItem<>(new TableData(typ));
        TreeItem<TableData> p3 = new TreeItem<>(new TableData(pth));

        TreeItem<TableData> root1 = new TreeItem<>(new TableData(nm));
        TreeItem<TableData> root2 = new TreeItem<>(new TableData("Type"));
        TreeItem<TableData> root3 = new TreeItem<>(new TableData("Path"));

        root1.getChildren().setAll(root2);
        root2.getChildren().setAll(p2, root3);
        root3.getChildren().setAll(p3);
        parent.getChildren().add(root1);
        NameColumn.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getOneString());
        TreeTableHome.setRoot(parent);
        TreeTableHome.setShowRoot(false);

    }

    public void PieChart(int select, int value, int value2) {
        PaneView.getChildren().clear();
        if (select == 0) {
            jClasses = value;
            jintf = value2;
        }
        if (select == 1) {
            csharpClasses = value;
            caIntf = value2;
        }
        if (select == 2) {
            pythonClasses = value;
        }
        ObservableList<PieChart.Data> piedata = FXCollections.observableArrayList();
        piedata.add(new PieChart.Data("Java Classes", jClasses));
        piedata.add(new PieChart.Data("CSharp Classes", csharpClasses));
        piedata.add(new PieChart.Data("Java Interface", jintf));
        piedata.add(new PieChart.Data("CSharp Interface", caIntf));
        PieChart PieChartt = new PieChart(piedata);
        //PieChartt.setStartAngle(180.0);
        double j = 0.8;
        PieChartt.setScaleX(j);
        PieChartt.setScaleY(j);
        PieChartt.setScaleZ(j);
        PieChartt.setTitle("Classes Quantities");
        PaneView.getChildren().add(PieChartt);
    }

    @FXML
    public void ButtonzipChose(ActionEvent event) {
        openFile(0);
        File selectedFile = fChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Unzip(selectedFile.getAbsolutePath());
        } else {
            System.out.println("Select Zip File Please");
        }
    }

    @FXML
    public void ButtonfolderChose(ActionEvent event) {
        openFile(1);
    }

    @FXML
    public void ButtonfileChose(ActionEvent event) {
        openFile(2);
        File selectedFile = fChooser.showOpenDialog(null);
        if (selectedFile != null) {
            String st1 = selectedFile.getAbsolutePath().replace("\\", "/");
            addpath(st1);
        } else {
            System.out.println("Path Not Added My Be Already Added");
        }
    }

    @FXML
    public void ButtonMultiplefileChose(ActionEvent event) {
       // System.out.println("I am in multi file");
        fChooser = new FileChooser();
        List<File> selectedFile = fChooser.showOpenMultipleDialog(null);
        if (selectedFile != null) {
            for (int i = 0; i < selectedFile.size(); i++) {
                String st1 = selectedFile.get(i).getAbsolutePath().replace("\\", "/");
                addpath(st1);
            }
        } else {
            System.out.println("Path Not Added My Be Already Added");
        }
    }

    public void printPath() {
        for (int i = 0; i < patharry.size(); i++) {
            System.out.println("I am Print Path:  " + patharry.get(i));
        }
    }

    public void Spliting(String addString) {

        String[] arrOfStr = addString.split("/");
        String st3 = arrOfStr[arrOfStr.length - 1].replace(".", "/");
        String[] St1 = st3.split("/");
        InsertDataIntoTable(St1[0], St1[1], addString.replace(arrOfStr[arrOfStr.length - 1], ""));
    }

    public void openFile(int chk) {
        fChooser = new FileChooser();
        if (chk == 0) {
            fChooser.getExtensionFilters().addAll(new ExtensionFilter("Zip File", "*.zip"));
        } else if (chk == 1) {
            directoryChose();
        } else {
            fChooser.getExtensionFilters().addAll(new ExtensionFilter("Java File", "*.java"));
            fChooser.getExtensionFilters().addAll(new ExtensionFilter("C Sharp", "*.cs"));
            //  fChooser.getExtensionFilters().addAll(new ExtensionFilter("Python", "*.csv"));

        }

    }

    public void directoryChose() {
        DirectoryChooser dchoser = new DirectoryChooser();
        File file = dchoser.showDialog(null);
        {
            String filePath = "";
            if (file != null) {
                File[] files = file.listFiles();
                for (File x : files) {

                    if (x.isFile()) {

                        filePath = file.getAbsolutePath() + "\\" + x.getName();
                        String st1 = filePath.replace("\\", "/");
                        addpath(st1);

                    }
                }
                if (patharry.size() < 1) {

                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Chose Folder");
                    alert.setHeaderText(null);
                    alert.setContentText("May Be this Folder Not Contain Any File\n                       Thanks!");
                    alert.showAndWait();
                }
            }
        }
    }

    public void Unzip(String path) {
        String inputpath = path;
        String outpath = path.substring(0, path.length() - 4);
       // System.out.println("I am path" + inputpath + "\n I am path 2" + outpath);
        unZip(inputpath, outpath);
    }

    public ArrayList<String> getPath() {
        return patharry;
    }

    private void unZip(String zipFile, String extractFolder) {
        try {
            int BUFFER = 2048;
            File file = new File(zipFile);

            ZipFile zip = new ZipFile(file);
            String newPath = extractFolder;

            new File(newPath).mkdir();
            Enumeration zipFileEntries = zip.entries();

            // Process each entry
            while (zipFileEntries.hasMoreElements()) {
                // grab a zip file entry
                ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
                String currentEntry = entry.getName();

                File destFile = new File(newPath, currentEntry);
                //destFile = new File(newPath, destFile.getName());
                File destinationParent = destFile.getParentFile();
                String st1 = destFile.getAbsolutePath().replace("\\", "/");
                addpath(st1);
                destinationParent.mkdirs();

                if (!entry.isDirectory()) {
                    BufferedInputStream is = new BufferedInputStream(zip
                            .getInputStream(entry));
                    int currentByte;
                    // establish buffer for writing file
                    byte data[] = new byte[BUFFER];

                    // write the current file to disk
                    FileOutputStream fos = new FileOutputStream(destFile);
                    BufferedOutputStream dest = new BufferedOutputStream(fos,
                            BUFFER);

                    // read and write until last byte is encountered
                    while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
                        dest.write(data, 0, currentByte);
                    }
                    dest.flush();
                    dest.close();
                    is.close();
                }

            }
        } catch (Exception e) {
            System.out.println("Its an Exception in RarChosing");
        }

    }

    public void addpath(String cPath) {
        Extractor extractor = new Extractor();
        if (cPath.endsWith(".java") || cPath.endsWith(".cs")) {
            boolean flag = true;
            for (int i = 0; i < patharry.size(); i++) {
                if (cPath.equals(patharry.get(i))) {
                    flag = false;
                }
            }
            if (flag) {
                if (cPath.endsWith(".java")) {
                    extractor.extractFromFile(cPath);
                    if (extractor.interfacesfound.size() != 0) {
                        jintf++;
                    } else {
                        jClasses++;
                    }
                    PieChart(0, jClasses, jintf);
                }
                if (cPath.endsWith(".cs")) {
                    extractor.extractFromFile(cPath);
                    if (extractor.interfacesfound.size() != 0) {
                        caIntf++;
                    } else {
                        csharpClasses++;
                    }
                    PieChart(1, csharpClasses, caIntf);
                }
                patharry.add(cPath);
                Spliting(cPath);
            }
            flag = true;
        }
    }
}
