package projectextractor;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ClassDiagramViewController implements Initializable {

    @FXML
    private ScrollPane DiagramScrollPane;
    private TextArea T1;
    private TextArea T2;
    private TextArea T3;
    VBox VBoxroot = new VBox();
    String st = new String();
    @FXML
    private BarChart<?, ?> DiagramChart;
    int globalVariables=0,totallmethods=0,tolocalvariables=0,toclasstypes=0; 
    int no=0;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void Do() {
        int m=0,p=0,g=0;
        if (ar.size() > 0) {
            for (int i = 0; i < ar.size(); i++) {
                if(ar.get(i).endsWith("java"))
                    m=1;
                if(ar.get(i).endsWith("cs"))
                    p=1;
                if(ar.get(i).endsWith("python"))
                    g=1;
                diagram(ar.get(i));
            }
        }
        toclasstypes=m+p+g;
        VariablesExpenceChart(ar.size(),globalVariables,tolocalvariables, totallmethods,toclasstypes);
        ScrollPane();
    }

    public void VariablesExpenceChart(double classes, double variables,double localVariables, double methods, double classTypes) {
        XYChart.Series Classes = new XYChart.Series<>();
        Classes.setName("Classes");
        Classes.getData().add(new XYChart.Data("Classes", classes));

        XYChart.Series Method = new XYChart.Series<>();
        Method.setName("Methods");
        Method.getData().add(new XYChart.Data("Methods", methods));

        XYChart.Series ClassTypes = new XYChart.Series<>();
        ClassTypes.setName("Class Type");
        ClassTypes.getData().add(new XYChart.Data("Class Type", classTypes));

        XYChart.Series Variables = new XYChart.Series<>();
        Variables.setName("Global Var");
        Variables.getData().add(new XYChart.Data("Golobal Var", variables));
        
         XYChart.Series LocalVariables = new XYChart.Series<>();
        Variables.setName("Local Var");
        Variables.getData().add(new XYChart.Data("Local Var", localVariables));
        DiagramChart.getData().addAll(Classes, Method, ClassTypes, Variables,LocalVariables);
    }
    private ArrayList<String> ar = new ArrayList();

      public int[] getSizes(String path) {
        Extractor extractor = new Extractor();
        extractor.extractFromFile(path);

        int v1 = 0, v2 = 0, m = 0;
        boolean flag = true;
        ClassElements c=null;
        InterfaceElements e=null;
        if (extractor.interfacesfound.size() == 0) {
            c = (ClassElements) extractor.classesfound.get(0);
            flag=true;
        } else {
            e = (InterfaceElements) extractor.interfacesfound.get(0);
            flag = false;
        }

        if (flag) {
            for (int k = 0; k < c.methods.size(); k++) {
                MethodElements meth = (MethodElements) c.methods.get(k);
                v2 = v2 + meth.localVariables.size();
            }

            v1 = c.attributes.size();
            m = c.methods.size();
        } else {
            for (int k = 0; k < e.methods.size(); k++) {
                MethodElements meth = (MethodElements) e.methods.get(k);
                v2 = v2 + meth.localVariables.size();
            }

            v1 = e.attributes.size();
            m = e.methods.size();
        }
        
        globalVariables=globalVariables+v1;
        tolocalvariables=tolocalvariables+v2;
        totallmethods=totallmethods+m;        
        int[] size = new int[4];
        size[0] = v1;
        size[1] = v2;
        size[2] = m;
        size[3] = getMax(new int[]{v1, v2, m});
        return size;
    }
     
     
    public int getMax(int[] inputArray) {
        int maxValue = inputArray[0];
        for (int i = 1; i < inputArray.length; i++) {
            if (inputArray[i] > maxValue) {
                maxValue = inputArray[i];
            }
        }
        return maxValue;
    }
     
   protected void diagram(String path) {
        
        
            int[] sizes = getSizes(path);
             Extractor extractor = new Extractor();
        extractor.extractFromFile(path);    
            boolean flag = true;
        ClassElements c=null;
        InterfaceElements e=null;
        if (extractor.interfacesfound.size() == 0) {
            c = (ClassElements) extractor.classesfound.get(0);
            flag=true;
        } else {
            e = (InterfaceElements) extractor.interfacesfound.get(0);
            flag = false;
        }          
        VBox Vbox1 = new VBox();
        int temp=0;
        if(sizes[0]<1)
            temp=1;
        else
            temp=sizes[0];
        int namesize=20;
        if(extractor.interfacesfound.size()!=0)
          namesize=37;
        
        int noVariables = temp+1;
        int noMethods = sizes[2]+1;
        String[] path1 = path.split("/");
        String mt = path1[path1.length - 1].replace(".", "/");
        String[] path2 = mt.split("/");
        Rectangle rectangle = new Rectangle(250, 30, 370, namesize);
        rectangle.setFill(Color.DARKGOLDENROD);
        rectangle.setStroke(Color.BLACK);
        rectangle.setCursor(Cursor.HAND);

        Rectangle rectangle2 = new Rectangle(250, 30, 370, 17 * noVariables);
        rectangle2.setFill(Color.DARKKHAKI);
        rectangle2.setStroke(Color.BLACK);
        rectangle2.setCursor(Cursor.HAND);

        Rectangle rectangle3 = new Rectangle(250, 30, 370, 17 * noMethods);
        rectangle3.setFill(Color.DARKKHAKI);
        rectangle3.setStroke(Color.BLACK);
        rectangle3.setCursor(Cursor.HAND);
        
       if(flag)
       {final Text text1 = new Text(c.name);
        final StackPane stack1 = new StackPane();
        stack1.getChildren().addAll(rectangle, text1);
           String methodsvariables="";
         for (int i = 0; i < sizes[0]; i++){
                Attribute at = (Attribute) c.attributes.get(i);             
             
              if(methodsvariables.isEmpty())
              {
                  methodsvariables="+"+at.name+" : "+at.returnType;
              }
              else
              {
                methodsvariables=methodsvariables+"\n"+"+"+at.name+" : "+at.returnType;
              }
        
         }
         final Text text2 = new Text(methodsvariables);
        final StackPane stack2 = new StackPane();
        stack2.getChildren().addAll(rectangle2, text2);
    String methodsdiagram="";
        for (int i = 0; i < sizes[2]; i++){
              MethodElements meth = (MethodElements) c.methods.get(i);
                String gt1 = meth.signature;
                String gt2 = meth.signature;
                gt2 = gt2.substring(gt2.indexOf("(") + 1, gt2.indexOf(")"));
                gt1 = gt1.substring(0, gt1.indexOf("("));
                
                String[] split = gt1.split(" ");
             
                String kt="";
                     if(split[0].equals("public"))
                         kt="+";
                     else if(split[0].equals("private"))
                         kt="-";
                     else if(split[0].equals("protected"))
                         kt="#";
                     else
                         kt="+";
                  if(methodsdiagram.isEmpty())
              {
                  methodsdiagram=kt+meth.name+"("+gt2+") : "+split[1];
              }
              else
              {
             methodsdiagram=methodsdiagram+"\n"+kt+meth.name+"("+gt2+") : "+split[1];
              }
        }
          
        final Text text3 = new Text(methodsdiagram);
        final StackPane stack3 = new StackPane();
        stack3.getChildren().addAll(rectangle3, text3);

        Rectangle rectangle4 = new Rectangle(250, 30, 370, 15);
        rectangle4.setFill(Color.DARKGRAY);
        no++;
        final Text text4 = new Text("Diagram No:  " + no);
        final StackPane stack4 = new StackPane();
        stack4.getChildren().addAll(rectangle4, text4);

        final Text text5 = new Text("\n");

        Vbox1.getChildren().add(stack4);
        Vbox1.getChildren().add(stack1);
        Vbox1.getChildren().add(stack2);
        Vbox1.getChildren().add(stack3);
        Vbox1.getChildren().add(text5);

        VBoxroot.getChildren().add(Vbox1);
       }
       else
       {
           final Text text1 = new Text("<<Interface>>\n     "+e.name);
        final StackPane stack1 = new StackPane();
        stack1.getChildren().addAll(rectangle, text1);
         String methodsvariables="";
         for (int i = 0; i < sizes[0]; i++){
                Attribute at = (Attribute) e.attributes.get(i);             
             
              if(methodsvariables.isEmpty())
              {
                  methodsvariables="+"+at.name+" : "+at.returnType;
              }
              else
              {
                methodsvariables=methodsvariables+"\n"+"+"+at.name+" : "+at.returnType;
              }
        
         }
         final Text text2 = new Text(methodsvariables);
        final StackPane stack2 = new StackPane();
        stack2.getChildren().addAll(rectangle2, text2);
    String methodsdiagram="";
        for (int i = 0; i < sizes[2]; i++){
              MethodElements meth = (MethodElements) e.methods.get(i);
                String gt1 = meth.signature;
                String gt2 = meth.signature;
                gt2 = gt2.substring(gt2.indexOf("(") + 1, gt2.indexOf(")"));
                gt1 = gt1.substring(0, gt1.indexOf("("));
                
                String[] split = gt1.split(" ");
             String kt = "";
            if (split[0].equals("public"))
                kt = "+";
            else if (split[0].equals("private"))
                kt = "-";
            else if (split[0].equals("protected"))
                kt = "#";
            else
                kt = "+";
                  if(methodsdiagram.isEmpty())
              {
                  methodsdiagram=kt+meth.name+"("+gt2+") : "+split[1];
              }
              else
              {
             methodsdiagram=methodsdiagram+"\n"+kt+meth.name+"("+gt2+") : "+split[1];
              }
        }
          
        final Text text3 = new Text(methodsdiagram);
        final StackPane stack3 = new StackPane();
        stack3.getChildren().addAll(rectangle3, text3);

        Rectangle rectangle4 = new Rectangle(250, 30, 370, 15);
        rectangle4.setFill(Color.DARKGRAY);
        no++;
        final Text text4 = new Text("Diagram No:  " + no);
        final StackPane stack4 = new StackPane();
        stack4.getChildren().addAll(rectangle4, text4);

        final Text text5 = new Text("\n");

        Vbox1.getChildren().add(stack4);
        Vbox1.getChildren().add(stack1);
        Vbox1.getChildren().add(stack2);
        Vbox1.getChildren().add(stack3);
        Vbox1.getChildren().add(text5);

        VBoxroot.getChildren().add(Vbox1);
          
       }
    }

    public void ScrollPane() {

        DiagramScrollPane.setFitToWidth(true);
        // DiagramScrollPane.setFitToHeight(true);
        // DiagramScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        //DiagramScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        // DiagramScrollPane.setPrefSize(500, 250);
        DiagramScrollPane.setContent(VBoxroot);
        //DiagramScrollPane.set
    }

    @FXML
    public void DiagramBack(ActionEvent event) {
        try {
            //Load second scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("DetailFile.fxml"));
            Parent root = loader.load();
            DetailFileController detailfileController = loader.getController();
            detailfileController.setPaths(ar);
            detailfileController.Do();
            Stage stage1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage1.hide();
            stage1.setScene(new Scene(root));
            stage1.show();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    public void setPaths(ArrayList<String> arlist) {
        ar = arlist;
    }
}
