package projectextractor;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.Timer;
import sun.security.acl.OwnerImpl;

public class DetailFileController implements Initializable {
    private String type="";
    private String Pakistan = "";
    private int no = 0;
    private ChoseFileController cfc;
    private ArrayList<String> ar = new ArrayList();
    @FXML
    private ScrollPane DetailScrollPane;
    String className = "";
    VBox VBoxroot = new VBox();

    public void initialize(URL url, ResourceBundle rb) {

    }

    public void Do() {
        if (ar.size() > 0) {
            for (int i = 0; i < ar.size(); i++) {
                InsertDataIntoTable(ar.get(i));
            }
        }
        ScrollPane();
    }

    public void print() {

        for (int i = 0; i < ar.size(); i++) {
            System.out.println(ar.get(i));
        }
    }

    public void setPaths(ArrayList<String> arlist) {
        ar = arlist;
    }

    public void Exit(ActionEvent event) {
        Platform.exit();
        System.exit(0);
    }

    @FXML
    public void DetailBack(ActionEvent event) {
        try {
            //Load second scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ChoseFile.fxml"));
            Parent root = loader.load();
            Stage stage1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage1.hide();
            stage1.setScene(new Scene(root));
            stage1.show();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    public ObservableList<TableData> getObserveList() {
        ObservableList<TableData> row = FXCollections.observableArrayList();
        return row;
    }

    public void ScrollPane() {
        DetailScrollPane.setFitToWidth(true);
        DetailScrollPane.setContent(VBoxroot);
    }

    public int getMax(int[] inputArray) {
        int maxValue = inputArray[0];
        for (int i = 1; i < inputArray.length; i++) {
            if (inputArray[i] > maxValue) {
                maxValue = inputArray[i];
            }
        }
        return maxValue;
    }

    public int[] getSizes(String path) {
        Extractor extractor = new Extractor();
        extractor.extractFromFile(path);

        int v1 = 0, v2 = 0, m = 0;
        boolean flag = true;
        ClassElements c = null;
        InterfaceElements e = null;
        if (extractor.interfacesfound.size() == 0) {
            c = (ClassElements) extractor.classesfound.get(0);
            flag=true;
        } else {
            e = (InterfaceElements) extractor.interfacesfound.get(0);
            flag = false;
        }

        if (flag) {
            for (int k = 0; k < c.methods.size(); k++) {
                MethodElements meth = (MethodElements) c.methods.get(k);
                v2 = v2 + meth.localVariables.size();
            }

            v1 = c.attributes.size();
            m = c.methods.size();
        } else {
            for (int k = 0; k < e.methods.size(); k++) {
                MethodElements meth = (MethodElements) e.methods.get(k);
                v2 = v2 + meth.localVariables.size();
            }

            v1 = e.attributes.size();
            m = e.methods.size();
        }

        int[] size = new int[4];
        size[0] = v1;
        size[1] = v2;
        size[2] = m;
        size[3] = getMax(new int[]{v1, v2, m});
        return size;
    }

    public void InsertDataIntoTable(String path) {

        int[] sar = getSizes(path);
        System.out.println("We love Allah" + sar[0] + "  " + sar[1] + "  " + sar[2] + "  " + sar[3]);
        TreeTableColumn<TableData, String> NoVariables = new TreeTableColumn<>("tVariables");
        TreeTableColumn<TableData, String> Variables = new TreeTableColumn<>("Variables");
        TreeTableColumn<TableData, String> vRTypee = new TreeTableColumn<>("vRType");
        TreeTableColumn<TableData, String> LocalTo = new TreeTableColumn<>("vLocal To");
        TreeTableColumn<TableData, String> NoMethods = new TreeTableColumn<>("tMethods");
        TreeTableColumn<TableData, String> Methods = new TreeTableColumn<>("Methods");
        TreeTableColumn<TableData, String> mRType = new TreeTableColumn<>("mRType");
        TreeTableColumn<TableData, String> Parameters = new TreeTableColumn<>("mParameter");
        TreeTableColumn<TableData, String> Access = new TreeTableColumn<>("Access");

        TreeItem<TableData> parent = new TreeItem<>(new TableData("Class Names"));
        TreeTableView<TableData> TreeTableHome = new TreeTableView<TableData>();
        TreeTableHome.getColumns().setAll(NoVariables, Variables, vRTypee, LocalTo, NoMethods, Methods, mRType, Parameters, Access);
        TreeItem<TableData> root1 = new TreeItem<>(new TableData("Class Names"));

        String[] path1 = path.split("/");
        String mt = path1[path1.length - 1].replace(".", "/");
        String[] path2 = mt.split("/");
        root1 = addTable(sar, path, root1);
              
        final Text text3 = new Text("Class Name:     " + className + "\nClass Type:       " + path2[1]+type + "\nClass Path:       " + path);

        NoVariables.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getNoVariables());
        Variables.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getVariables());
        vRTypee.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getvRTypee());
        LocalTo.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getLocalTo());
        NoMethods.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getNoMethods());
        Methods.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getMethods());
        mRType.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getmRType());
        Parameters.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getParameters());
        Access.setCellValueFactory((TreeTableColumn.CellDataFeatures<TableData, String> param) -> param.getValue().getValue().getAccess());

        Rectangle rectangle4 = new Rectangle(250, 30, 860, 20);
        rectangle4.setFill(Color.DARKGOLDENROD);
        no++;
        final Text text2 = new Text("Class No:   " + no);
        final StackPane stack2 = new StackPane();
        stack2.getChildren().addAll(rectangle4, text2);

        final Text text4 = new Text("\n");

        TreeTableHome.setRoot(root1);
        TreeTableHome.setShowRoot(false);
        VBoxroot.getChildren().add(stack2);
        VBoxroot.getChildren().add(text3);
        VBoxroot.getChildren().add(TreeTableHome);
        VBoxroot.getChildren().add(text4);

    }

    public TreeItem<TableData> addTable(int[] sizes, String path, TreeItem<TableData> root1) {

        Extractor extractor = new Extractor();
        extractor.extractFromFile(path);
          if(extractor.interfacesfound.size()!=0)
            type=" <<Interface>>";
          else 
              type="";
        
        int j = 0;
        int m = 0;
        String local = "";
        boolean flag = true;
        ClassElements c = null;
        InterfaceElements e = null;
        if (extractor.interfacesfound.size() == 0) {
            c = (ClassElements) extractor.classesfound.get(0);
            flag = true;
        } else {
            e = (InterfaceElements) extractor.interfacesfound.get(0);
            flag = false;
        }

        if (flag) {
            className = c.name;
            for (int k = 0; k < sizes[2]; k++) {
                MethodElements meth = (MethodElements) c.methods.get(k);

                for (int l = 0; l < meth.localVariables.size(); l++) {
                    Attribute att = (Attribute) meth.localVariables.get(l);
                    if (local.isEmpty()) {
                        m++;
                        local = local + att.name + "@" + att.returnType + "@" + meth.name;
                    } else {
                        m++;
                        local = local + "/" + att.name + "@" + att.returnType + "@" + meth.name;
                    }
                }
            }

            String[] split2 = local.split("/");
            System.out.println("I am local sizes" + split2.length + " gv size" + sizes[0] + " lc size" + sizes[1] + "method size" + sizes[2] + "max" + sizes[3]);
            for (int i = 0; i < (sizes[0] + sizes[1]+sizes[2]); i++) {
                String st1 = "", st2 = "", st3 = "", st4 = "", st5 = "", st6 = "", st7 = "", st8 = "", st9 = "";
                if (i == 0) {
                    st1 = "" + (sizes[0] + sizes[1]);
                    st5 = "" + sizes[2];
                }
                if (i < sizes[2]) {
                    System.out.println("I am in methods");
                    MethodElements meth = (MethodElements) c.methods.get(i);
                    String gt1 = meth.signature;
                    String gt2 = meth.signature;

                    if (!gt2.contains(")") && gt2.length() > 0) {
                        gt2 = gt2 + ")";
                    }
                    System.out.println("I am gt2" + gt2);
                    if (!gt2.isEmpty()) {
                        gt2 = gt2.substring(gt2.indexOf("(") + 1, gt2.indexOf(")"));
                    }
                    if (!gt1.isEmpty()) {
                        gt1 = gt1.substring(0, gt1.indexOf("("));
                    }
                    if (gt2.isEmpty()) {
                        gt2 = "no parameter";
                    }
                    String[] split = gt1.split(" ");
                    st6 = meth.name;
                    
                       String kt="";
                     if(split[0].equals("public"))
                         kt="(+)public";
                     else if(split[0].equals("private"))
                         kt="(-)private";
                     else if(split[0].equals("protected"))
                         kt="(#)protected";
                     else
                         kt="(+)public";
                    
                    st9 = kt;
                    st7 = split[1];
                    st8 = gt2;
                }
                if (i < sizes[0]) {
                    j++;
                    Attribute at = (Attribute) c.attributes.get(i);

                    st2 = "" + at.name;

                    st3 = "" + at.returnType;
                    st4 = "GLOBAL";
                } else {

                    int p = i - j;
                    if (p < sizes[1] && sizes[2] > 0) {
                        String[] split3 = split2[p].split("@");
                        st2 = split3[0];
                        st3 = split3[1];
                        st4 = split3[2];

                    }
                }

                TreeItem<TableData> p1 = new TreeItem<>(new TableData(st1, st2, st3, st4, st5, st6, st7, st8, st9));
                root1.getChildren().add(p1);
            }
        } else {
            className = e.name;
    
            for (int i = 0; i < (sizes[0] + sizes[1]+sizes[2]); i++) {
                String st1 = "", st2 = "", st3 = "", st4 = "", st5 = "", st6 = "", st7 = "", st8 = "", st9 = "";
                if (i == 0) {
                    st1 = "" + (sizes[0] + sizes[1]);
                    st5 = "" + sizes[2];
                }
                if (i < sizes[2]) {
                    System.out.println("I am in methods");
                    MethodElements meth = (MethodElements) e.methods.get(i);
                    String gt1 = meth.signature;
                    String gt2 = meth.signature;

                    if (!gt2.contains(")") && gt2.length() > 0) {
                        gt2 = gt2 + ")";
                    }
                    System.out.println("I am gt2" + gt2);
                    if (!gt2.isEmpty()) {
                        gt2 = gt2.substring(gt2.indexOf("(") + 1, gt2.indexOf(")"));
                    }
                    if (!gt1.isEmpty()) {
                        gt1 = gt1.substring(0, gt1.indexOf("("));
                    }
                    if (gt2.isEmpty()) {
                        gt2 = "no parameter";
                    }
                    String[] split = gt1.split(" ");
                    st6 = meth.name;
                       String kt="";
                     if(split[0].equals("public"))
                         kt="(+)public";
                     else if(split[0].equals("private"))
                         kt="(-)private";
                     else if(split[0].equals("protected"))
                         kt="(#)protected";
                     else
                         kt="(+)public";
                    
                    st9 = kt;
                    st7 = split[1];
                    st8 = gt2;
                }
                if (i < sizes[0]) {
                    j++;
                    Attribute at = (Attribute) e.attributes.get(i);

                    st2 = "" + at.name;
                    st3 = "" + at.returnType;
                    st4 = "GLOBAL";
                } 

                TreeItem<TableData> p1 = new TreeItem<>(new TableData(st1, st2, st3, st4, st5, st6, st7, st8, st9));
                root1.getChildren().add(p1);
            }
        }
        return root1;
    }

    @FXML
    public void ClassDiagram(ActionEvent event
    ) {
     
        try {
            //Load second scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ClassDiagramView.fxml"));
            Parent root = loader.load();
            ClassDiagramViewController detailfileController = loader.getController();
            detailfileController.setPaths(ar);
            detailfileController.Do();
            Stage stage1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage1.hide();
            stage1.setScene(new Scene(root));
            stage1.show();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

}
