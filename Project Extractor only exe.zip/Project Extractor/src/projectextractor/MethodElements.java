package projectextractor;

class MethodElements {

    String name;
    String signature;
    MyArrayList localVariables; // Of type Attributes

    MethodElements() {
        localVariables = new MyArrayList();
    }

    MethodElements(String name, String signature) {
        this.name = name;
        this.signature = signature;
        localVariables = new MyArrayList();
    }

}
