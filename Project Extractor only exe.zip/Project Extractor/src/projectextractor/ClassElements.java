package projectextractor;

class ClassElements {

    String name;
    MyArrayList attributes; // Of type Attributes
    MyArrayList methods; // Of type MethodElements

    ClassElements() {
        attributes = new MyArrayList();
        methods = new MyArrayList();
    }

    ClassElements(String name) {
        this.name = name;
        attributes = new MyArrayList();
        methods = new MyArrayList();
    }

    void addMethod(String name, String signature) {
        methods.add(new MethodElements(name, signature));
    }

    void addAttribute(String returnType, String name) {
        if (methods.isEmpty()) {
            attributes.add(new Attribute(returnType, name));
        } else {
            MethodElements recentAddedMethod = (MethodElements) methods.get(methods.size() - 1);
            recentAddedMethod.localVariables.add(new Attribute(returnType, name));
        }
    }

    void printData() {
        System.out.println("------------------");
        System.out.println(name);

        System.out.println("\nGLOBAL VARIABLES");
        for (int i = 0; i < attributes.size(); i++) {
            Attribute a = (Attribute) attributes.get(i);
            System.out.println(a.returnType + " " + a.name);
        }

        System.out.println("\nLOCAL VARIABLES");
        for (int i = 0; i < methods.size(); i++) {
            MethodElements m = (MethodElements) methods.get(i);
            for (int j = 0; j < m.localVariables.size(); j++) {
                Attribute a = (Attribute) m.localVariables.get(j);
                System.out.println(a.returnType + " " + a.name + " LOCAL TO " + m.name);
            }
        }

        System.out.println("\nMETHOD SIGNATURES");
        for (int i = 0; i < methods.size(); i++) {
            MethodElements m = (MethodElements) methods.get(i);
            System.out.println(m.signature);
        }
        System.out.println("------------------");
    }

}
