package projectextractor;

import java.io.BufferedReader;
import java.io.File;
import java.util.Scanner;
import java.io.IOException;
import java.io.FileNotFoundException;

public class Extractor {

    String currentFileType;
    MyArrayList classesfound;
    MyArrayList interfacesfound;

    String javaReturnTypes[] = {"int", "float", "boolean", "long",
        "char", "double", "short", "byte",
        "String", "void"};
    String cSharpReturnTypes[] = {"int", "float", "bool", "long",
        "char", "double", "short", "byte",
        "String", "decimal", "byte", "void"};

    Extractor() {
        classesfound = new MyArrayList();
        interfacesfound = new MyArrayList();
    }

    // Reads lines form the file
    public void extractFromFile(String path) {
        try {
            File file = new File(path);
            Scanner sc = new Scanner(file);

            // Extract File type using the File name
            String fileName = file.getName();
            currentFileType = fileName.substring(fileName.indexOf(".") + 1, fileName.length());

            // If it is a Java File
            if (currentFileType.equals("java")) {
                while (sc.hasNextLine()) {
                    //process the line
                    processJavaLine(sc.nextLine());
                }
            } // If it is a C# File
            else if (currentFileType.equals("cs")) {
                while (sc.hasNextLine()) {
                    //process the line
                    processCSharpLine(sc.nextLine());
                }
            } // File type not supported
            else {
                System.out.println("File type \"" + currentFileType + "\" not supported for extraction.");
            }

            sc.close();
        } catch (FileNotFoundException ex) {
            System.out.printf("File not found on path\n\"%s\"", path);
        }
    }

    // Process a java line of code and exract information
    private void processJavaLine(String rawLine) {

        // If comment, ignore
        if (rawLine.contains("//")) {
            rawLine = rawLine.substring(0, rawLine.indexOf("//"));
        }

        String[] words = split(rawLine);

        // If class found
        int classIndex = getIndexOf("class", words);
        if (classIndex != -1) {

            // If it is not a string that says class
            if (!rawLine.contains("\"")) {
                classesfound.add(new ClassElements(words[classIndex + 1]));
            }
        }

        // If interface found
        int interfaceIndex = getIndexOf("interface", words);
        if (interfaceIndex != -1) {

            // If it is not a string that says class
            if (!rawLine.contains("\"")) {
                interfacesfound.add(new InterfaceElements(words[interfaceIndex + 1]));
            }
        }

        // If return type found on the line
        for (String rt : javaReturnTypes) {
            int rtIndex = getIndexOf(rt, words);
            if (rtIndex != -1) {

                // This current file has interface
                if (!interfacesfound.isEmpty()) {

                    // If line has attribute
                    if (rawLine.contains(";") & !rawLine.contains("(")) {
                        InterfaceElements recentAddedInterface = (InterfaceElements) interfacesfound.get(interfacesfound.size() - 1);
                        recentAddedInterface.addAttribute(words[rtIndex], words[rtIndex + 1]);
                    } // if line has method signature
                    else {
                        // Skip to net return type found, if return type in method signature is detected
                        if (rawLine.indexOf("(") < rawLine.indexOf(words[rtIndex])) {
                            continue;
                        }

                        String mName = words[rtIndex + 1];
                        int i = (rawLine.indexOf(";"));
                        i = (i == -1) ? rawLine.length() : i;

                        String mSignature = rawLine.substring(0, i);

                        InterfaceElements recentAddedInterface = (InterfaceElements) interfacesfound.get(interfacesfound.size() - 1);
                        recentAddedInterface.addMethod(mName, mSignature.trim());
                    }
                } // This current file has class(es) in it
                else if (!classesfound.isEmpty()) {
                    // If line has attribute
                    if (rawLine.contains(";")) {
                        ClassElements recentAddedClass = (ClassElements) classesfound.get(classesfound.size() - 1);
                        recentAddedClass.addAttribute(words[rtIndex], words[rtIndex + 1]);
                    } // if line has method signature
                    else {
                        // Skip to net return type found, if return type in method signature is detected
                        if (rawLine.indexOf("(") < rawLine.indexOf(words[rtIndex])) {
                            continue;
                        }

                        String mName = words[rtIndex + 1];
                        int i = (rawLine.indexOf("{"));
                        i = (i == -1) ? rawLine.length() : i;

                        String mSignature = rawLine.substring(0, i);

                        ClassElements recentAddedClass = (ClassElements) classesfound.get(classesfound.size() - 1);
                        recentAddedClass.addMethod(mName, mSignature.trim());
                    }
                }

            }
        }
    }

    // Process a C# line of code and exract information
    private void processCSharpLine(String rawLine) {

        // If comment, ignore
        if (rawLine.contains("//")) {
            rawLine = rawLine.substring(0, rawLine.indexOf("//"));
        }

        String[] words = split(rawLine);

        // If class found
        int classIndex = getIndexOf("class", words);
        if (classIndex != -1) {

            // If it is not a string that says class
            if (!rawLine.contains("\"")) {
                classesfound.add(new ClassElements(words[classIndex + 1]));
            }
        }

        // If interface found
        classIndex = getIndexOf("interface", words);
        if (classIndex != -1) {

            // If it is not a string that says class
            if (!rawLine.contains("\"")) {
                classesfound.add(new ClassElements(words[classIndex + 1]));
            }
        }

        // If return type found on the line
        for (String rt : cSharpReturnTypes) {
            int rtIndex = getIndexOf(rt, words);
            if (rtIndex != -1) {

                // This current file has interface
                if (!interfacesfound.isEmpty()) {

                    // If line has attribute
                    if (rawLine.contains(";") & !rawLine.contains("(")) {
                        InterfaceElements recentAddedInterface = (InterfaceElements) interfacesfound.get(interfacesfound.size() - 1);
                        recentAddedInterface.addAttribute(words[rtIndex], words[rtIndex + 1]);
                    } // if line has method signature
                    else {
                        // Skip to net return type found, if return type in method signature is detected
                        if (rawLine.indexOf("(") < rawLine.indexOf(words[rtIndex])) {
                            continue;
                        }

                        String mName = words[rtIndex + 1];
                        int i = (rawLine.indexOf(";"));
                        i = (i == -1) ? rawLine.length() : i;

                        String mSignature = rawLine.substring(0, i);

                        InterfaceElements recentAddedInterface = (InterfaceElements) interfacesfound.get(interfacesfound.size() - 1);
                        recentAddedInterface.addMethod(mName, mSignature.trim());
                    }
                } // This current file has class(es) in it
                else if (!classesfound.isEmpty()) {
                    // If line has attribute
                    if (rawLine.contains(";")) {
                        ClassElements recentAddedClass = (ClassElements) classesfound.get(classesfound.size() - 1);
                        recentAddedClass.addAttribute(words[rtIndex], words[rtIndex + 1]);
                    } // if line has method signature
                    else {
                        // Skip to net return type found, if return type in method signature is detected
                        if (rawLine.indexOf("(") < rawLine.indexOf(words[rtIndex])) {
                            continue;
                        }

                        String mName = words[rtIndex + 1];
                        int i = (rawLine.indexOf("{"));
                        i = (i == -1) ? rawLine.length() : i;

                        String mSignature = rawLine.substring(0, i);

                        ClassElements recentAddedClass = (ClassElements) classesfound.get(classesfound.size() - 1);
                        recentAddedClass.addMethod(mName, mSignature.trim());
                    }
                }

            }
        }
    }

    // Custom utility s function to extract tokens
    private String[] split(String s) {
        MyArrayList tokens = new MyArrayList();
        StringBuilder token = new StringBuilder();
        int count = 0;
        for (char c : s.toCharArray()) {
            switch (c) {
                case ' ':
                case '{':
                case '}':
                case ';':
                case '(':
                case ')':
                case '\n':
                    if (!token.toString().equals("")) {
                        tokens.add(token.toString());
                        token = new StringBuilder();
                    }
                    break;

                default:
                    token.append(c);
            }
        }

        if (!token.toString().equals("")) {
            tokens.add(token.toString());
        }

        String[] temp = new String[tokens.size()];
        for (int i = 0; i < tokens.size(); i++) {
            temp[i] = (String) tokens.get(i);
        }

        return temp;
    }

    // Utility function to check if a string varaiable is present in string array
    private int getIndexOf(String word, String words[]) {
        int i = 0;
        for (String w : words) {
            if (word.equals(w)) {
                return i;
            }
            i++;
        }

        return -1;
    }

    // Printing the extraction results
    public void printResults() {
        for (int i = 0; i < classesfound.size(); i++) {
            ClassElements c = (ClassElements) classesfound.get(i);
            c.printData();
        }

        for (int i = 0; i < interfacesfound.size(); i++) {
            InterfaceElements interf = (InterfaceElements) interfacesfound.get(i);
            interf.printData();
        }
    }
}
