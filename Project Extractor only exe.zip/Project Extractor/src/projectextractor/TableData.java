package projectextractor;

import javafx.beans.property.SimpleStringProperty;

public class TableData {

    SimpleStringProperty NoVariables, Variables, vRTypee, LocalTo, NoMethods, Methods, mRType, Parameters, Access, oneString;

    public TableData(String NoVariables, String Variables, String vRTypee, String LocalTo, String NoMethods, String Methods, String mRType, String Parameters, String Access) {
        this.NoVariables = new SimpleStringProperty(NoVariables);
        this.Variables = new SimpleStringProperty(Variables);
        this.vRTypee = new SimpleStringProperty(vRTypee);
        this.LocalTo = new SimpleStringProperty(LocalTo);
        this.NoMethods = new SimpleStringProperty(NoMethods);
        this.Methods = new SimpleStringProperty(Methods);
        this.mRType = new SimpleStringProperty(mRType);
        this.Parameters = new SimpleStringProperty(Parameters);
        this.Access = new SimpleStringProperty(Access);
    }

    public TableData(String oneString) {
        this.oneString = new SimpleStringProperty(oneString);
    }

    public SimpleStringProperty getNoVariables() {
        return NoVariables;
    }

    public SimpleStringProperty getVariables() {
        return Variables;
    }

    public SimpleStringProperty getvRTypee() {
        return vRTypee;
    }

    public SimpleStringProperty getOneString() {
        return oneString;
    }

    public SimpleStringProperty getAccess() {
        return Access;
    }

    public SimpleStringProperty getParameters() {
        return Parameters;
    }

    public SimpleStringProperty getmRType() {
        return mRType;
    }

    public SimpleStringProperty getMethods() {
        return Methods;
    }

    public SimpleStringProperty getLocalTo() {
        return LocalTo;
    }

    public SimpleStringProperty getNoMethods() {
        return NoMethods;
    }

}
