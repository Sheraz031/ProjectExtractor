package projectextractor;

class Attribute {

    String returnType;
    String name;

    Attribute() {
    }

    Attribute(String returnType, String name) {
        this.returnType = returnType;
        this.name = name;
    }
}
