package projectextractor;

class InterfaceElements {

    String name;
    MyArrayList attributes;
    MyArrayList methods;

    InterfaceElements() {
        attributes = new MyArrayList();
        methods = new MyArrayList();
    }

    InterfaceElements(String name) {
        this.name = name;
        attributes = new MyArrayList();
        methods = new MyArrayList();
    }

    void addMethod(String name, String signature) {
        methods.add(new MethodElements(name, signature));
    }

    void addAttribute(String returnType, String name) {

        attributes.add(new Attribute(returnType, name));
    }

    void printData() {
        System.out.println("------------------");
        System.out.println(name);

        System.out.println("\nVARIABLES");
        for (int i = 0; i < attributes.size(); i++) {
            Attribute a = (Attribute) attributes.get(i);
            System.out.println(a.returnType + " " + a.name);
        }

        System.out.println("\nMETHOD SIGNATURES");
        for (int i = 0; i < methods.size(); i++) {
            MethodElements m = (MethodElements) methods.get(i);
            System.out.println(m.signature);
        }
        System.out.println("------------------");
    }
}
